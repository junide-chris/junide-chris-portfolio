// Typing Animation
const typed = new Typed('.auto-type', {
    strings: ['a Front-End Developer', 'a 3D Modeler', 'a Creative Designer'],
    typeSpeed: 100,
    backSpeed: 100,
    loop: true
});

// Speedometer Animation
const needle = document.querySelector('.speed-needle');
let rotation = 0;

function animateSpeedometer() {
    rotation = (rotation + 1) % 180;
    needle.style.transform = `rotate(${rotation}deg)`;
    requestAnimationFrame(animateSpeedometer);
}

animateSpeedometer();

// Smooth Scrolling
document.querySelectorAll('a[href^="#"]').forEach(anchor => {
    anchor.addEventListener('click', function (e) {
        e.preventDefault();
        document.querySelector(this.getAttribute('href')).scrollIntoView({
            behavior: 'smooth'
        });
    });
});

// Skill Meter Animation
const observer = new IntersectionObserver((entries) => {
    entries.forEach(entry => {
        if (entry.isIntersecting) {
            entry.target.style.width = entry.target.dataset.width;
        }
    });
}, { threshold: 0.5 });

document.querySelectorAll('.fill').forEach(meter => {
    observer.observe(meter);
});

// Contact Form
document.getElementById('contact-form').addEventListener('submit', function(e) {
    e.preventDefault();
    // Add your form submission logic here
    alert('Message sent successfully!');
    this.reset();
}); 